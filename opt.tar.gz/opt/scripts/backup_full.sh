#!/bin/bash

DESTINO_BASE="/backup_dir"
LOG_FILE="/var/log/backup_script.log"

if [[ "$1" == "-help" ]]; then
  echo "Uso: $0 ORIGEN DESTINO"
  echo "Ejemplo: $0 /var/log /backup_dir"
  exit 0
fi

ORIGEN="$1"
DESTINO="${2:-$DESTINO_BASE}"

if [[ -z "$ORIGEN" || -z "$DESTINO" ]]; then
  echo "Error: Debes indicar el origen y el destino del backup."
  echo "Usá -help para más info."
  exit 1
fi

if [[ ! -d "$ORIGEN" ]]; then
  echo "Error: El directorio de origen $ORIGEN no existe."
  exit 2
fi

if [[ ! -d "$DESTINO" ]]; then
  echo "Error: El directorio de destino $DESTINO no existe."
  exit 3
fi

ESPACIO_NECESITADO=$(du -s "$ORIGEN" | awk '{print $1}')
ESPACIO_DISPONIBLE=$(df --output=avail "$DESTINO" | tail -1)
if [[ $ESPACIO_NECESITADO -gt $ESPACIO_DISPONIBLE ]]; then
  echo "Error: Espacio insuficiente en $DESTINO."
  exit 4
fi


NOMBRE=$(basename "$ORIGEN")
FECHA=$(date +%Y%m%d)
ARCHIVO="${NOMBRE}_bkp_${FECHA}.tar.gz"

if ! tar -czf "$DESTINO/$ARCHIVO" "$ORIGEN"; then
  echo "Error al crear el backup."
  exit 5
fi

chmod 440 "$DESTINO/ARCHIVO"

echo "[$(date +'%Y-%m-%d %H:%M:%S')] Backup de $ORIGEN a $DESTINO/$ARCHIVO" >> "$LOG_FILE"

echo "Backup creado con éxito: $DESTINO/$ARCHIVO"
exit 0
